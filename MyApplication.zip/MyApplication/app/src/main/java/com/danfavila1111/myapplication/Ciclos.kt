package com.danfavila1111.myapplication

class Ciclos {
}

fun main(){
    /* EJERCICIO 1
    for (i in 1 .. 5) print(i)
    println()

    for (i in 5 downTo 1) print(i)

    for (i in 1 .. 5 step 2) print(i)
    */

    /* EJERCICIO 2 FOR
    var par = 0
    var impar = 0
    var sumpar=0
    var sumimpar=0
    for (i in 1 .. 6){
        println("Ingrese el primer numero $i")
        var num1: Int= readLine()!!.toInt()
        var result=num1 % 2
        if (result==0){
            println("Su numero es par")
            par++
            sumpar=sumpar+num1
        }
        else{
            println("Su numero es impar")
            impar++
            sumimpar=sumimpar+num1
        }
        println("La cantidad de numeros pares es $par y la cantidad de impares es $impar")
        println("La suma de los pares es $sumpar")
        println("La suma de los impares es $sumimpar")
    }
    */

    /* EJERCICIO 2 WHILE
    var par = 0
    var impar = 0
    var sumpar=0
    var sumimpar=0
    var p = "si"
    while (p == "si"){
        var num1: Int= readLine()!!.toInt()
        if (num1 % 2 == 0){
            println("El numero es par")
            par++
            sumpar=sumpar+num1
        }
        else{
            println("El numero es impar")
            impar++
            sumimpar=sumimpar+num1
        }
        print("¿Quiere ingresar otro numero?")
        p = readLine()!!.toString()
    }
    println("Los numeros pares son $par y la suma es $sumpar")
    println("Los numeros impares son $impar y la suma es $sumimpar")
    */

    /* EJERCICIO 2 DO WHILE
    var par = 0
    var impar = 0
    var sumpar=0
    var sumimpar=0
    var p = "si"
    do {
        var num1: Int= readLine()!!.toInt()
        if (num1 % 2 == 0){
            println("El numero es par")
            par++
            sumpar=sumpar+num1
        }
        else{
            println("El numero es impar")
            impar++
            sumimpar=sumimpar+num1
        }
        print("¿Quiere ingresar otro numero?")
        p = readLine()!!.toString()
    } while (p == "si")
    println("Los numeros pares son $par y la suma es $sumpar")
    println("Los numeros impares son $impar y la suma es $sumimpar")
    */

    /* EJERCICIO 3
    for (i in 'a' .. 'f') print(i)
     */
}