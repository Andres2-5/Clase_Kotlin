package com.danfavila1111.myapplication

class Introduction {
}

fun main() {
    var name:String ="Daniel"
    var a: Long= 999999999999999999
    var b: Int= 999999999
    var c: Short= 9999
    var d: Byte= 99
    var e: Double = 9.99999999999999
    var f: Float= 9.999999F
    var g: Char= '9'
    var h: Boolean= false

}